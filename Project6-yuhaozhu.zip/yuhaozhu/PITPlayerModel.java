/**
 * @author: Charlie Zhu
 * @use: The PITPlayerModel Class
 * <p>
 * This is the ONLY file that you are to edit. It is the model of play for every PITplayer.
 * Each PITplayer instantiates this model and uses it to process the messages it receives.
 * <p>
 * This project has three tasks:
 * 1. Add monopoly-seeking behavior to the players in a simulation.
 * 2. Add the Chandy-Lamport Snapshot Algorithm into a distributed system.
 * 3. Use the Chandy-Lamport Snapshot to understand the behavior of a system.
 * <p>
 * Implement the Chandy Lamport Snapshot Algorithm. This algorithm can obtain a global state
 * of a distributed system. The construction also requires the setting up of JMS resources.
 * <p>
 * The distributed system has five players. Each player has a set of commodities which it
 * trades with the other players. Trades are more like gifts than exchanges. When each player
 * receives a commodity from someone, it gives one of its commodities to another player. It
 * might be the same player, or it may be another player. It picks who to give the Trade to
 * randomly. The trading action therefore is a fast series of accepting commodities from the
 * others and giving commodities to others.
 * <p>
 * Each of the 6 players is modeled as a Message Driven Bean. The code for each is nearly
 * identical, except for its class name, the Queue it listens to, and an instance variable
 * named myPlayerNumber. Each of the players instantiates a PITPlayerModel which does all
 * the business (game) logic for the simulation.
 * <p>
 * All communication between the players is done by JMS Message Queues. Each player has its
 * own Queue that it listens to. Other players can communicate with the player by sending a
 * message to its Queue.
 * <p>
 * A servlet and a Test Snapshot web page allows the system to be tested. Clicking on the Start
 * Simulation button will start the simulation running. The servlet will send a series of
 * messages to each Player's Queue.
 * <p>
 * Trading continues until the maxTrades threshold is hit. This can be adjusted in the
 * PITPlayerModel so the trading does not go on forever. The trading can also be stopped by
 * clicking the Halt Simulation button on the Test Snapshot page.
 * A new round of trading can then be started by using the PITsnapshot servlet again.
 * <p>
 * Last Modified: Oct 20, 2019
 * Class: 95-702 Distributed Systems
 * Assignment: Project 6 Task 1
 */

package pit;

import javax.jms.*;
import javax.naming.Context;
import javax.naming.InitialContext;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public class PITPlayerModel {

    // I. Members + Constructor

    // Each PITplayer has a unique myPlayerNumber.  It is set in the PITPlayer constructor.
    private final int myPlayerNumber;
    // Cards is this player's set of cards.
    private final ArrayList cards = new ArrayList();
    // numTrades counts trades.
    private int numTrades = 0;
    // maxTrades is the maximum number of trades, after which trading is stopped.
    private final int maxTrades = 20000;
    // numPlayers are the number of Players trading.  This comes with a NewHand from the PITsnapshot servlet
    private int numPlayers = 0;
    // halting indicates that the system is being reset, so ignore trades until a new had received
    private boolean halting = false;
    // doRecord indicates whether this player need to record the incoming messages
    private boolean doRecord = false;
    // markers record who have sent this player a Marker
    private ArrayList<Integer> markers = new ArrayList<>();

    private HashMap<String, Integer> myState;
    private HashMap<String, Integer> state;
    /* The snapshot servlet (PITsnapshot) is expecting to be passed an ObjectMessage
     * where the object is a HashMap. Therefore this definition of HashMap is
     * provided although it is not currently used (it is for you to use).
     * PITsnapshot is expecting a set of attribute/value pairs. These include the player
     * number, as in state.put("Player",myPlayerNumber), and each commodity string
     * and the number of that commodity in the snapshot.
     * Also included below is a utility method that will convert a HashMap into a string
     * which is useful for printing diagnostic messages to the console.
     */

    /**
     * PITPlayerModel constructor saves what number player this object represents.
     *
     * @param myNumber
     */
    PITPlayerModel (int myNumber) {
        myPlayerNumber = myNumber;
        state = new HashMap<>();
        state.put("Player", myPlayerNumber);
    }

    /**
     * Create a string of hand size and all cards
     *
     * @param hand
     * @return
     */
    private String toString (ArrayList hand) {
        String cardsString = "size: " + hand.size() + " ";
        for (int i = 0; i < hand.size(); i++) {
            cardsString += hand.get(i) + " ";
        }
        return cardsString;
    }

    /**
     * Create a printable version of the "state".
     *
     * @param state
     * @return
     */
    private String toString (HashMap<String, Integer> state) {
        String stateString = "";
        for (Iterator it = state.entrySet().iterator(); it.hasNext(); ) {
            Map.Entry entry = (Map.Entry) it.next();
            String commodity = (String) entry.getKey();
            int number = ((Integer) entry.getValue()).intValue();
            stateString += "{" + commodity + ":" + number + "} ";
        }
        return stateString;
    }

    // II. Helpers

    /**
     * Send an object to a Queue, given its JNDI name
     *
     * @param queueJNDI
     * @param message
     * @throws Exception
     */
    private void sendToQueue (String queueJNDI, Serializable message) throws Exception {
        // Gather necessary JMS resources
        Context ctxt = new InitialContext();
        Connection con = ((ConnectionFactory) ctxt.lookup("openejb:Resource/myConnectionFactory")).createConnection();
        Session session = con.createSession(false, Session.AUTO_ACKNOWLEDGE);
        Queue q = (Queue) ctxt.lookup(queueJNDI);
        MessageProducer writer = session.createProducer(q);
        ObjectMessage msg = session.createObjectMessage(message);
        // Send the object to the Queue
        writer.send(msg);
        session.close();
        con.close();
        ctxt.close();
    }

    /**
     * Stop trading when the max number of Trades is reached
     *
     * @param max
     * @return
     */
    private boolean maxTrades (int max) {
        if ((numTrades % 100) == 0) {
            System.out.println("PITplayer" + myPlayerNumber + " numTrades: " + numTrades);
        }
        return (numTrades++ < max) ? false : true;
    }

    /**
     * Record the state of this player
     *
     * @param state
     */
    private void recordState (HashMap<String, Integer> state) {
        for (int i = 0; i < cards.size(); i++) {
            String card = (String) (cards.get(i));
            if (state.containsKey(card)) {
                state.put(card, state.get(card) + 1);
            } else {
                state.put(card, 1);
            }
        }
    }

    /**
     * If the source player of this trade has not seen the Marker sent out by me,
     * keep track of incoming messages by adding card into snapshot.
     *
     * @param source
     * @param card
     */
    private void addSnapshot (int source, String card) {
        if (!markers.contains(source) && doRecord) {
            if (state.containsKey(card)) {
                state.put(card, state.get(card) + 1);
            } else {
                state.put(card, 1);
            }
        }
    }

    /**
     * Do Maker sending rule
     *
     * @throws Exception
     */
    private void sendMarker () throws Exception {
        if (halting) {
            return;
        }
        // Send Marker to each outgoing channel
        for (int i = 0; i < numPlayers; i++) {
            if (i != myPlayerNumber) {
                System.out.println("Player" + myPlayerNumber + " sends marker to Player" + i);
                String sendToJNDI = "openejb:Resource/PITplayer" + i;
                sendToQueue(sendToJNDI, new Marker(myPlayerNumber));
            }
        }
    }

    // III. Listener methods

    /**
     * There are 6 types of messages:
     * Reset, NewHand, TenderOffer, AcceptOffer, RejectOffer, and Marker
     *
     * @param message
     */
    public void onMessage (Message message) {
        try {
            if (message instanceof ObjectMessage) {
                Object o = ((ObjectMessage) message).getObject();

                // Reset the Player.  This message is generated by the PITsnapshot servlet
                if (o instanceof Reset) {
                    doReset((Reset) o);

                    // NewHand received from PITsnapshot
                } else if (o instanceof NewHand) {
                    // Add the new hand into cards
                    doNewHand((NewHand) o);

                    // Receive an offer from another Player
                } else if (o instanceof TenderOffer) {
                    doReceiveTenderOffer((TenderOffer) o);

                    // Another Player accepted our offer
                } else if (o instanceof AcceptOffer) {
                    doReceiveAcceptOffer((AcceptOffer) o);

                    // Another Player rejected our offer
                } else if (o instanceof RejectOffer) {
                    doReceiveRejectOffer((RejectOffer) o);

                } else if (o instanceof Marker) {
                    // Marker comes in
                    doReceiveMarker((Marker) o);

                } else {
                    System.out.println("PITplayer" + myPlayerNumber + " received unknown Message type");
                    // just ignore it
                }
            }
        } catch (Exception e) {
            System.out.println("Exception thrown in PITplayer" + myPlayerNumber + ": " + e);
        }
    }

    /**
     * Resetting is done by two messages, first to halt, then to clear
     *
     * @param reset
     * @throws Exception
     */
    private void doReset (Reset reset) throws Exception {
        if (reset.action == Reset.HALT) {
            System.out.println("PITplayer" + myPlayerNumber + " received Reset HALT");
            halting = true;
            // Reply to the PITsnapshot servlet acknowledging the Reset HALT
            sendToQueue("openejb:Resource/PITmonitor", reset);
        } else { // action == Reset.CLEAR
            System.out.println("PITplayer" + myPlayerNumber + " received Reset RESET");
            // Drop all cards in hand
            cards.clear();
            numTrades = 0;
            numPlayers = 0;
            halting = false;
            // Reply to the PITsnapshot servlet acknowledging the Reset
            sendToQueue("openejb:Resource/PITmonitor", reset);
        }
    }

    /**
     * Add a new hand of cards.
     * It is actually possible that an offer from another Player has been
     * accepted already, beating the NewHand
     *
     * @param hand
     * @throws Exception
     */
    private void doNewHand (NewHand hand) throws Exception {
        cards.addAll((hand).newHand);
        numPlayers = (hand).numPlayers;
        System.out.println("PITplayer" + myPlayerNumber + " new hand: " + toString(cards));
        // Offer a card to another Player
        doTenderOffer();
    }

    /**
     * Add monopoly-seeking behavior to the players in a simulation.
     *
     * @param trade
     * @throws Exception
     */
    private void doReceiveTenderOffer (TenderOffer trade) throws Exception {
        if (halting) {
            return; // if halting, discard trade
        }

        System.out.println("PITplayer" + myPlayerNumber + " received offer of: " + trade.tradeCard + " from player: " + trade.sourcePlayer);
        // Keep track of incoming messages if certain conditions are met
        addSnapshot(trade.sourcePlayer, trade.tradeCard);

        // Find the the commodity whose count is the max
        int maxCount = -1;
        String maxCard = "";
        for (Map.Entry<String, Integer> entry : myState.entrySet()) {
            if (!entry.getKey().equals("Player")) {
                if (entry.getValue() > maxCount) {
                    maxCount = entry.getValue();
                    maxCard = entry.getKey();
                }
            }
        }
        System.out.println("Player" + myPlayerNumber + ": " + maxCard + " holds the maximum count at " + maxCount);

        // If the tradecard received is the one this player want
        // aka it is the commodity this player holds the most
        // Accept the offer
        if (trade.tradeCard.equals(maxCard)) {
            // Add the offer to my hand of cards
            cards.add(trade.tradeCard);
            // Update the myState
            myState.clear();
            myState.put("Player", myPlayerNumber);
            recordState(myState);
            // Pay with one of my cards (the commodity I hold the least)
            doReplyAccept(trade.sourcePlayer);
        } else {
            doReplyReject(trade);
        }
    }

    /**
     * Reply accepting an offer that was received.
     *
     * @param sendTo
     * @throws Exception
     */
    private void doReplyAccept (int sendTo) throws Exception {
        // if hit maxTrades limit, then stop sending trades
        if (maxTrades(maxTrades)) {
            return;
        }

        // In payment for the card I just accepted, send back one of my cards.
        AcceptOffer newTrade = new AcceptOffer();

        // Find the commodity with the minimum count
        int minCount = Integer.MAX_VALUE;
        String minCard = "";
        for (Map.Entry<String, Integer> entry : myState.entrySet()) {
            if (!entry.getKey().equals("Player")) {
                if (entry.getValue() < minCount) {
                    minCount = entry.getValue();
                    minCard = entry.getKey();
                }
            }
        }
        System.out.println("Player" + myPlayerNumber + ": " + minCard + " holds the minimum count at " + minCount);
        // Find the position of the first occurence of the commodity with the minimun count
        for (int i = 0; i < cards.size(); i++) {
            String card = (String) (cards.get(i));
            if (card.equals(minCard)) {
                // Send this card back
                newTrade.tradeCard = (String) cards.remove(i);
                break;
            }
        }

        newTrade.sourcePlayer = myPlayerNumber;
        myState.clear();
        myState.put("Player", myPlayerNumber);
        recordState(myState);

        //Send the card to the other player
        System.out.println("PITplayer" + myPlayerNumber + " accepting offer and paying with: " + newTrade.tradeCard + " to player: " + sendTo);
        System.out.println("PITplayer" + myPlayerNumber + " hand: " + toString(cards));
        String sendToJNDI = "openejb:Resource/PITplayer" + sendTo;
        sendToQueue(sendToJNDI, newTrade);
    }

    /**
     * Reply rejecting an offer that was received.
     * Send back their card.
     *
     * @param trade
     * @throws Exception
     */
    private void doReplyReject (TenderOffer trade) throws Exception {
        if (halting) {
            return; // if halting, discard trade
        }

        System.out.println("PITplayer" + myPlayerNumber + " rejecting offer of: " + trade.tradeCard + " from player: " + trade.sourcePlayer);
        System.out.println("PITplayer" + myPlayerNumber + " hand: " + toString(cards));

        // if hit maxTrades limit, then stop sending trades
        if (maxTrades(maxTrades)) {
            return;
        }

        // Send back their card that I am rejecting
        RejectOffer newTrade = new RejectOffer();
        newTrade.tradeCard = trade.tradeCard;
        newTrade.sourcePlayer = myPlayerNumber;

        //Send the card to the other player
        String sendToJNDI = "openejb:Resource/PITplayer" + trade.sourcePlayer;
        sendToQueue(sendToJNDI, newTrade);
    }

    /**
     * Handle receiving a message that a previous offer has been accepted.
     * They would have replied with another card as payment.
     *
     * @param trade
     * @throws Exception
     */
    private void doReceiveAcceptOffer (AcceptOffer trade) throws Exception {
        if (halting) {
            return; // if halting, discard trade
        }

        // Having received a AcceptOffer from another Player, add it to my hand of cards
        cards.add(trade.tradeCard);
        // Keep track of incoming messages if certain conditions are met
        addSnapshot(trade.sourcePlayer, trade.tradeCard);

        System.out.println("PITplayer" + myPlayerNumber + " received: " + trade.tradeCard + " as payment from player: " + trade.sourcePlayer);
        System.out.println("PITplayer" + myPlayerNumber + " hand: " + toString(cards));
        // Make another offer to a random player
        doTenderOffer();
    }

    /**
     * Handle receiving a reject message regarding a prior offer I made
     *
     * @param trade
     * @throws Exception
     */
    private void doReceiveRejectOffer (RejectOffer trade) throws Exception {
        if (halting) {
            return; // if halting, discard trade
        }

        // Because the offer was rejected, and returned, add it back into my cards
        cards.add(trade.tradeCard);
        // Keep track of incoming messages if certain conditions are met
        addSnapshot(trade.sourcePlayer, trade.tradeCard);

        System.out.println("PITplayer" + myPlayerNumber + " received rejected offer of: " + trade.tradeCard + " from player: " + trade.sourcePlayer);
        System.out.println("PITplayer" + myPlayerNumber + " hand: " + toString(cards));
        // Make another offer to a random player
        doTenderOffer();
    }

    /**
     * Make an offer to a random player
     *
     * @throws Exception
     */
    private void doTenderOffer () throws Exception {

        // if hit maxTrades limit, then stop sending trades
        if (maxTrades(maxTrades)) {
            return;
        }
        /*
         * If numPlayers == 0, while we have received a TenderOffer, we have not
         * received our NewHand yet, so we don't know how many players there
         * are.  Therefore, don't send out a TenderOffer at this time.
         *
         */
        if (numPlayers == 0) {
            return;
        }

        // Create a new offer from my set of cards, and send to another player
        TenderOffer newTrade = new TenderOffer();

        // Initiate an offer by randomly choose a card to offer
        int position = (int) (Math.random() * cards.size());
        newTrade.tradeCard = (String) cards.remove(position);
        newTrade.sourcePlayer = myPlayerNumber;

        // Update the myState
        myState.clear();
        myState.put("Player", myPlayerNumber);
        recordState(myState);

        // Find a random player to trade to (not including myself)
        int sendTo = myPlayerNumber;
        while (sendTo == myPlayerNumber) {
            sendTo = Math.round((float) Math.random() * (numPlayers - 1));
        }

        //Send the card to the other player
        System.out.println("PITplayer" + myPlayerNumber + " offered: " + newTrade.tradeCard + " to player: " + sendTo);
        String sendToJNDI = "openejb:Resource/PITplayer" + sendTo;
        sendToQueue(sendToJNDI, newTrade);
    }

    /**
     * Handle situation when Marker is received
     *
     * @param marker
     * @throws Exception
     */
    private void doReceiveMarker (Marker marker) throws Exception {
        System.out.println("Player" + myPlayerNumber + " got Marker from Player" + marker.source);

        // if the marker is from the monitor
        boolean isSource = false;
        if (marker.source == -1) {
            // Record my state now
            recordState(state);
            // Do Marker sending rule
            sendMarker();
            isSource = true;
            doRecord = true;
        }

        if (markers.isEmpty()) {
            // If this is the first time this player has ever received a Marker
            if (!isSource) {
                recordState(state);
            }
            doRecord = true;

            System.out.println("Player" + myPlayerNumber + " adds " + marker.source + " to the markers");
            // Add the new source player to the markers list
            markers.add(marker.source);
            // Send out the Marker to each outgoing channel
            sendMarker();

        } else if (markers.size() < numPlayers - 1) {
            // If this player hasn't seen Markers from every other player
            System.out.println("Player" + myPlayerNumber + " adds " + marker.source + " to the markers");
            // Add the new source player to the markers list
            markers.add(marker.source);
            for (int i = 0; i < markers.size(); i++) {
                System.out.print(markers.get(i) + " ");
            }

        } else {
            // This is last channel to receive marker on
            System.out.println("Player" + myPlayerNumber + ": got all markers back");
            // Send records to the Monitor process
            String queueJNDI = "openejb:Resource/PITsnapshot";
            sendToQueue(queueJNDI, state);
            // reset the state of this player
            markers.clear();
            state.clear();
            state.put("Player", myPlayerNumber);
            doRecord = false;
        }
    }
}