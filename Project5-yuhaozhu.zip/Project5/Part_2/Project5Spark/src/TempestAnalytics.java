/**
 * @author: Charlie Zhu
 * @use: The TempestAnalytics Class
 * <p>
 * Use Spark to analyze the TheTempest.txt file.
 * <p>
 * Last Modified: Nov 7, 2019
 * Class: 95-702 Distributed Systems
 * Assignment: Project 5 Part 2
 */

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import scala.Tuple2;

import java.util.Arrays;
import java.util.Scanner;

public class TempestAnalytics {

    /**
     * Perform analytics tasks as required on the text file passed
     *
     * @param fileName
     */
    private static void tempestAnalytics (String fileName) {

        // switch off the logs
        Logger.getLogger("org").setLevel(Level.OFF);
        Logger.getLogger("akka").setLevel(Level.OFF);

        // initialize the settings
        System.setProperty("hadoop.home.dir", "hadoop");
        SparkConf sparkConf = new SparkConf().setMaster("local").setAppName("Tempest Analytics");
        JavaSparkContext sparkContext = new JavaSparkContext(sparkConf);

        // Task 0.
        // Using the count method of the JavaRDD class, display the number of lines in "The Tempest".

        // create a new JavaRDD that containes each line of the text file
        JavaRDD<String> inputFile = sparkContext.textFile(fileName);
        // print the number of lines
        System.out.println("Task 0: " + inputFile.count() + " lines");

        // Task 1.
        // Using the split method of the java String class and the flatMap method of the JavaRDD class,
        // use the count method of the JavaRDD class to display the number of words in The Tempest.

        // create a new JavaRDD that containes each word of the text file
        JavaRDD<String> wordsFromFile = inputFile.flatMap(content -> Arrays.asList(content.split(" ")));
        // print the number of words
        System.out.println("Task 1: " + wordsFromFile.count() + " words");

        // Task 2.
        // Using some of the work you did above and the JavaRDD distinct() and count() methods, display
        // the number of distinct words in The Tempest.

        // print the number of distinct words
        System.out.println("Task 2: " + wordsFromFile.distinct().count() + " distinct words");

        // Task 3.
        // Using the JavaPairRDD class and the saveAsTextFile() method along with the JavaRDD class
        // and the mapToPair() method, show each word paired with the digit 1 in the output directory
        // named /TheTempestOutputDir1. You may re-use RDD's from the above tasks if appropriate.

        // create a new JavaPairRDD that pairs each word with digit 1
        JavaPairRDD wordsPairOne = wordsFromFile.mapToPair(t -> new Tuple2(t, 1));
        // save to the directory
        wordsPairOne.saveAsTextFile("TheTempestOutputDir1");

        // Task 4.
        // Using work from above and the JavaPairRDD from Task 3, create a new JavaPairRDD with the
        // reduceByKey() method. Save the RDD using the saveAsTextFile() method and place the result
        // in the output directory named /TheTempestOutputDir2.

        // create a new JavaPairRDD that pairs each word with its frequencies
        JavaPairRDD wordsPairCount = wordsFromFile.mapToPair(t -> new Tuple2(t, 1)).reduceByKey((x, y) -> (int) x + (int) y);
        // save to the directory
        wordsPairCount.saveAsTextFile("TheTempestOutputDir2");

        // Task 5.
        // Using work from above and the JavaRDD foreach() method, prompt the user for a string and
        // then perform a search on every line of the The Tempest. If any line of The Tempest
        // contains the String entered by the user then display the entire line.

        // ask user for search string
        System.out.println("Please input the string to search:");
        Scanner in = new Scanner(System.in);
        String searchStr = in.nextLine().trim();
        System.out.println("Lines in the Tempest including \'" + searchStr + "\' are:");

        // search the string from the user and print the lines including the string
        inputFile.foreach((str) -> {
            if (str.contains(searchStr))
                System.out.println(str);
        });
    }

    /**
     * Main Function
     *
     * @param args
     */
    public static void main (String[] args) {
        
        // if no arguments are passed, warn the user
        if (args.length == 0) {
            System.out.println("No files provided.");
            System.exit(0);
        }
        // do the analytics tasks
        tempestAnalytics(args[0]);
    }
}